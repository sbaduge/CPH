# py-execute-with-php

01. add this in to your local server 
02. chnage relative path of each py file according to your python inatllation location
03. start 

