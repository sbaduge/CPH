<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sample Project</title>


</head>
<body>
<?php
    if(isset($_POST['submit'])){
        if(!empty($_POST['cards'])) {
            $selected = $_POST['cards'];
            switch ($selected) {
                case "visa":
                    $command = escapeshellcmd('visa.py');
                    $output = shell_exec($command);
                    echo $output;
                    break;
                case "master":
                    $command = escapeshellcmd('master.py');
                    $output = shell_exec($command);
                    echo $output;
                    break;
                case "amex":
                    $command = escapeshellcmd('amex.py');
                    $output = shell_exec($command);
                    echo $output;
                    break;
                case "delta":
                    $command = escapeshellcmd('delta.py');
                    $output = shell_exec($command);
                    echo $output;
                    break;
                case "fishers":
                    $command = escapeshellcmd('fishers.py');
                    $output = shell_exec($command);
                    echo $output;
                    break;
                default:
                    echo 'Please select one';
                    break;   
            }
        } else {
            echo 'Please select one';
        }
    }
?>
<div style="margin:50px">
    <form action="" method="post">
    <select name="cards">
        <option value="" selected>Select option</option>
        <option value="master">Master</option>
        <option value="visa">Visa</option>
        <option value="amex">Amex</option>
        <option value="delta">Delta</option>
        <option value="fishers">Fishers</option>
    </select>

    <input type="submit" name="submit" value="execute">
    </form>
</div>

</body>
</html>





