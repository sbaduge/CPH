#!c:python27/python.exe
# print("content-type:text/html\r\n\r\n")

print("Amex")